package sportspulse.analytics;
import sportspulse.ds.DynamicArray;
import sportspulse.model.Player;
public class Analytics{
 public static double averageScore(DynamicArray<Player> ps){double s=0;for(int i=0;i<ps.size();i++)s+=ps.get(i).score;return ps.size()==0?0:s/ps.size();}
 public static Player topScorer(DynamicArray<Player> ps){Player b=null;for(int i=0;i<ps.size();i++)if(b==null||ps.get(i).score>b.score)b=ps.get(i);return b;}
 public static Player topAllRounder(DynamicArray<Player> ps){Player b=null;double bs=-1;for(int i=0;i<ps.size();i++){Player p=ps.get(i);double v=p.score*.4+p.assists*.2+p.speed*20*.15+p.accuracy*.15+p.stamina*.1;if(v>bs){bs=v;b=p;}}return b;}
 public static void dashboard(DynamicArray<Player> ps){System.out.println("\n--- SPORTSPULSE DASHBOARD ---");System.out.println("Players: "+ps.size());System.out.printf("Average score: %.2f%n",averageScore(ps));System.out.println("Top scorer: "+topScorer(ps));System.out.println("Composite all-round score leader: "+topAllRounder(ps));}
}
