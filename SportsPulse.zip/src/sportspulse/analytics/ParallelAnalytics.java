package sportspulse.analytics;
public class ParallelAnalytics{
 public static long parallelSum(final int[] a,int threads)throws InterruptedException{if(a.length==0)return 0;final long[] part=new long[threads];Thread[] ts=new Thread[threads];for(int t=0;t<threads;t++){final int id=t;ts[t]=new Thread(()->{int from=a.length*id/threads,to=a.length*(id+1)/threads;long s=0;for(int i=from;i<to;i++)s+=a[i];part[id]=s;});ts[t].start();}for(int i=0;i<threads;i++)ts[i].join();long s=0;for(int i=0;i<threads;i++)s+=part[i];return s;}
 public static int[] prefixScan(int[] a){int[] out=new int[a.length];int s=0;for(int i=0;i<a.length;i++){s+=a[i];out[i]=s;}return out;}
}
