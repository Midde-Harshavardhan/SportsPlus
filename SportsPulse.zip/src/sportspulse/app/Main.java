package sportspulse.app;

import java.io.*;
import sportspulse.io.CsvLoader;
import sportspulse.ds.*;
import sportspulse.model.Player;
import sportspulse.analytics.*;
import sportspulse.string.*;
import sportspulse.dp.*;
import sportspulse.flow.*;
import sportspulse.np.*;
import sportspulse.random.*;

public class Main{
 static DynamicArray<Player> players;
 static BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
 static String findDataFile(){
  String[] candidates={"data/players.csv","SportsPulse/data/players.csv","../data/players.csv"};
  for(String p:candidates) if(new File(p).isFile()) return p;
  return "data/players.csv";
 }
 public static void main(String[] args)throws Exception{
  String path=args.length>0?args[0]:findDataFile();
  try{players=CsvLoader.load(path);}catch(Exception e){System.out.println("Could not load "+path+". Make sure data/players.csv exists.");return;}
  System.out.println("========================================");System.out.println("        SPORTSPULSE ANALYTICS");System.out.println(" Advanced DSA Sports Performance Engine");System.out.println("========================================");
  boolean run=true;while(run){menu();String c=in.readLine();if(c==null)break;switch(c){case "1":Analytics.dashboard(players);break;case "2":search();break;case "3":fuzzy();break;case "4":similarity();break;case "5":flow();break;case "6":np();break;case "7":prime();break;case "8":sample();break;case "9":parallel();break;case "0":run=false;break;default:System.out.println("Choose 0-9.");}}
  System.out.println("Thank you for using SportsPulse.");
 }
 static void menu(){System.out.println("\n1 Dashboard\n2 Search notes (KMP/Z/Rabin-Karp/Aho-Corasick)\n3 Fuzzy name matching (Edit Distance + alignment)\n4 Player similarity (Suffix Array + LCP)\n5 Performance flow network (Dinic / Max-Flow)\n6 NP-hard scheduling + Vertex Cover 2-approx\n7 Miller-Rabin primality test\n8 Reservoir sampling\n9 Parallel reduce + prefix scan\n0 Exit\nEnter choice: ");}
 static void search()throws Exception{System.out.print("Pattern: ");String p=in.readLine();String text="";for(int i=0;i<players.size();i++)text+=players.get(i).notes+" ";System.out.println("Naive index="+StringAlgorithms.naive(text,p));System.out.println("KMP index="+StringAlgorithms.kmp(text,p));System.out.println("Rabin-Karp index="+StringAlgorithms.rabinKarp(text,p));int[] z=StringAlgorithms.z(p+"$"+text);int best=0;for(int i=p.length()+1;i<z.length;i++)if(z[i]>best)best=z[i];System.out.println("Z-function best match length="+best);String[] pats={"excellent","accurate","strong","fast","stamina"};int[] hits=StringAlgorithms.ahoCorasickFirst(text,pats);System.out.print("Aho-Corasick first positions: ");for(int i=0;i<hits.length;i++)System.out.print(pats[i]+"="+hits[i]+" ");System.out.println();}
 static void fuzzy()throws Exception{System.out.print("Name to search: ");String q=in.readLine();int best=999;Player bp=null;for(int i=0;i<players.size();i++){Player p=players.get(i);int d=DPAlgorithms.levenshtein(q.toLowerCase(),p.name.toLowerCase());if(d<best){best=d;bp=p;}}System.out.println("Closest player: "+bp);System.out.println("Levenshtein distance="+best);if(bp!=null){System.out.println("Damerau-Levenshtein="+DPAlgorithms.damerau(q.toLowerCase(),bp.name.toLowerCase()));System.out.println("Needleman-Wunsch score="+DPAlgorithms.needlemanWunsch(q.toLowerCase(),bp.name.toLowerCase()));System.out.println("Smith-Waterman score="+DPAlgorithms.smithWaterman(q.toLowerCase(),bp.name.toLowerCase()));}}
 static void similarity()throws Exception{System.out.print("Player 1 name: ");String a=findName(in.readLine());System.out.print("Player 2 name: ");String b=findName(in.readLine());if(a==null||b==null){System.out.println("Player not found.");return;}String s=a+"#"+b;int[] sa=SuffixTools.suffixArray(s);int[] lcp=SuffixTools.kasai(s,sa);System.out.println("Suffix array: ");for(int x:sa)System.out.print(x+" ");System.out.println("\nLCP array: ");for(int x:lcp)System.out.print(x+" ");System.out.println("\nDirect LCP="+SuffixTools.longestCommonPrefix(a,b));}
 static String findName(String q){for(int i=0;i<players.size();i++)if(players.get(i).name.equalsIgnoreCase(q))return players.get(i).name;return null;}
 static void flow(){int n=players.size()+2,s=players.size(),t=s+1;MaxFlow mf=new MaxFlow(n);for(int i=0;i<players.size();i++){Player p=players.get(i);mf.addEdge(s,i,p.score/100+1);mf.addEdge(i,t,p.assists/30+1);}System.out.println("Dinic maximum performance-flow value="+mf.dinic(s,t));}
 static void np(){int[] d={3,2,5,4,6,2};int[] deadline={4,6,7,10,12,5};System.out.println("Greedy deadline scheduling completed jobs="+Approximation.greedySchedule(d,deadline));int[][] e={{0,1},{1,2},{2,3},{3,4},{4,5},{0,5},{1,4}};int[] c=Approximation.vertexCover2Approx(6,e);System.out.print("Vertex Cover 2-approx: ");for(int x:c)System.out.print(x+" ");System.out.println(" (size="+c.length+")");}
 static void prime()throws Exception{System.out.print("Enter integer: ");long n=Long.parseLong(in.readLine());System.out.println(n+" is "+(RandomAlgorithms.millerRabin(n,8)?"probably prime":"composite")+" (8-round Miller-Rabin).");}
 static void sample(){String[] names=new String[players.size()];for(int i=0;i<players.size();i++)names[i]=players.get(i).name;DynamicArray<String> s=RandomAlgorithms.reservoirSample(names,5,42);System.out.print("Uniform streaming sample: ");for(int i=0;i<s.size();i++)System.out.print(s.get(i)+" ");System.out.println();}
 static void parallel()throws Exception{int[] x=new int[100];for(int i=0;i<100;i++)x[i]=players.get(i%players.size()).score;System.out.println("Parallel sum (4 threads)="+ParallelAnalytics.parallelSum(x,4));int[] p=ParallelAnalytics.prefixScan(new int[]{3,1,4,1,5,9});System.out.print("Prefix scan: ");for(int v:p)System.out.print(v+" ");System.out.println();}
}
