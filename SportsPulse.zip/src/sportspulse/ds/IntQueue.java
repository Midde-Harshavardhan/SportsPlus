package sportspulse.ds;
public class IntQueue{private int[] a=new int[32];private int h=0,t=0;public boolean isEmpty(){return h==t;}public void add(int x){if(t==a.length){int[] b=new int[a.length*2];int n=t-h;for(int i=0;i<n;i++)b[i]=a[h+i];a=b;t=n;h=0;}a[t++]=x;}public int poll(){if(isEmpty())throw new IllegalStateException("empty queue");return a[h++];}}
