package sportspulse.ds;
public class IntStack{private int[] a=new int[32];private int n;public void push(int x){if(n==a.length){int[] b=new int[n*2];for(int i=0;i<n;i++)b[i]=a[i];a=b;}a[n++]=x;}public int pop(){if(n==0)throw new IllegalStateException("empty stack");return a[--n];}public boolean isEmpty(){return n==0;}}
