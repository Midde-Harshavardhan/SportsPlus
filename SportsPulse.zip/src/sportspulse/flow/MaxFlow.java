package sportspulse.flow;
import sportspulse.ds.IntQueue;
public class MaxFlow{
 private int[][] cap;private int n;
 public MaxFlow(int n){this.n=n;cap=new int[n][n];}
 public void addEdge(int u,int v,int c){cap[u][v]+=c;}
 public int fordFulkerson(int s,int t){int flow=0;while(true){int[] p=new int[n];for(int i=0;i<n;i++)p[i]=-1;p[s]=s;IntQueue q=new IntQueue();q.add(s);while(!q.isEmpty()&&p[t]<0){int u=q.poll();for(int v=0;v<n;v++)if(p[v]<0&&cap[u][v]>0){p[v]=u;q.add(v);}}if(p[t]<0)break;int f=Integer.MAX_VALUE;for(int v=t;v!=s;v=p[v])f=Math.min(f,cap[p[v]][v]);for(int v=t;v!=s;v=p[v]){cap[p[v]][v]-=f;cap[v][p[v]]+=f;}flow+=f;}return flow;}
 public int edmondsKarp(int s,int t){return fordFulkerson(s,t);}
 public int dinic(int s,int t){int flow=0;int[] level=new int[n],it=new int[n];while(bfsLevel(s,t,level)){for(int i=0;i<n;i++)it[i]=0;int f;while((f=dfs(s,t,Integer.MAX_VALUE,level,it))>0)flow+=f;}return flow;}
 private boolean bfsLevel(int s,int t,int[] level){for(int i=0;i<n;i++)level[i]=-1;level[s]=0;IntQueue q=new IntQueue();q.add(s);while(!q.isEmpty()){int u=q.poll();for(int v=0;v<n;v++)if(cap[u][v]>0&&level[v]<0){level[v]=level[u]+1;q.add(v);}}return level[t]>=0;}
 private int dfs(int u,int t,int f,int[] level,int[] it){if(u==t)return f;for(int v=it[u];v<n;v++,it[u]++){if(cap[u][v]>0&&level[v]==level[u]+1){int got=dfs(v,t,Math.min(f,cap[u][v]),level,it);if(got>0){cap[u][v]-=got;cap[v][u]+=got;return got;}}}return 0;}
}
