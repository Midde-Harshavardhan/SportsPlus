package sportspulse.io;
import java.io.*;
import sportspulse.ds.DynamicArray;
import sportspulse.model.Player;
public class CsvLoader{
 public static DynamicArray<Player> load(String path)throws IOException{
  DynamicArray<Player> out=new DynamicArray<>(); BufferedReader br=new BufferedReader(new FileReader(path)); String line=br.readLine();
  while((line=br.readLine())!=null){String[] p=split(line); if(p.length<11)continue; out.add(new Player(Integer.parseInt(p[0]),p[1],p[2],Integer.parseInt(p[3]),Integer.parseInt(p[4]),Integer.parseInt(p[5]),Double.parseDouble(p[6]),Double.parseDouble(p[7]),Double.parseDouble(p[8]),Integer.parseInt(p[9]),p[10]));}br.close();return out;
 }
 private static String[] split(String s){String[] x=new String[11];int k=0;StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='\"'){q=!q;continue;}if(c==','&&!q){x[k++]=b.toString();b.setLength(0);}else b.append(c);}x[k++]=b.toString();String[] r=new String[k];for(int i=0;i<k;i++)r[i]=x[i];return r;}
}
