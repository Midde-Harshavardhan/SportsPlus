package sportspulse.model;

public class Player {
    public final int id, matches, score, assists, injuryDays;
    public final String name, sport, notes;
    public final double speed, accuracy, stamina;
    public Player(int id,String name,String sport,int matches,int score,int assists,double speed,double accuracy,double stamina,int injuryDays,String notes){
        this.id=id;this.name=name;this.sport=sport;this.matches=matches;this.score=score;this.assists=assists;this.speed=speed;this.accuracy=accuracy;this.stamina=stamina;this.injuryDays=injuryDays;this.notes=notes;
    }
    public String toString(){return id+" | "+name+" | "+sport+" | score="+score+" | assists="+assists+" | speed="+speed+" | accuracy="+accuracy+" | stamina="+stamina+" | injuries="+injuryDays;}
}
