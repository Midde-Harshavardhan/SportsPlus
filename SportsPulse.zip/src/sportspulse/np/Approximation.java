package sportspulse.np;
public class Approximation{
 public static int[] vertexCover2Approx(int n,int[][] edges){boolean[] used=new boolean[n];int[] cover=new int[n];int k=0;for(int i=0;i<edges.length;i++){int u=edges[i][0],v=edges[i][1];if(!used[u]&&!used[v]){used[u]=used[v]=true;cover[k++]=u;cover[k++]=v;}}int[] r=new int[k];for(int i=0;i<k;i++)r[i]=cover[i];return r;}
 public static int greedySchedule(int[] duration,int[] deadline){boolean[] done=new boolean[duration.length];int time=0,count=0;while(true){int best=-1;for(int i=0;i<duration.length;i++)if(!done[i]&&(best<0||deadline[i]<deadline[best]))best=i;if(best<0)break;done[best]=true;time+=duration[best];if(time<=deadline[best])count++;}return count;}
}
