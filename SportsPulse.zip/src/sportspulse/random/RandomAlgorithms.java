package sportspulse.random;
import sportspulse.ds.DynamicArray;
public class RandomAlgorithms{
 public static boolean millerRabin(long n,int rounds){if(n<2)return false;int[] small={2,3,5,7,11,13,17,19,23,29,31,37};for(int p:small){if(n==p)return true;if(n%p==0)return false;}long d=n-1;int s=0;while((d&1)==0){d>>=1;s++;}long seed=88172645463325252L;for(int r=0;r<rounds;r++){seed=seed*2862933555777941757L+3037000493L;long a=2+floorMod(seed,n-3);long x=powMod(a,d,n);if(x==1||x==n-1)continue;boolean ok=false;for(int j=1;j<s;j++){x=mulMod(x,x,n);if(x==n-1){ok=true;break;}}if(!ok)return false;}return true;}
 private static long floorMod(long x,long m){long r=x%m;return r<0?r+m:r;}
 private static long mulMod(long a,long b,long m){long r=0;a%=m;while(b>0){if((b&1)==1)r=(r+a)%m;a=(a+a)%m;b>>=1;}return r;}
 private static long powMod(long a,long e,long m){long r=1%m;while(e>0){if((e&1)==1)r=mulMod(r,a,m);a=mulMod(a,a,m);e>>=1;}return r;}
 public static DynamicArray<String> reservoirSample(String[] items,int k,long seed){DynamicArray<String> out=new DynamicArray<>();if(k<=0)return out;for(int i=0;i<items.length&&i<k;i++)out.add(items[i]);int size=Math.min(k,items.length);for(int i=k;i<items.length;i++){seed=seed*1103515245L+12345;long x=(seed&0x7fffffffL)%(i+1);if(x<k){out.set((int)x,items[i]);}}return out;}
}
