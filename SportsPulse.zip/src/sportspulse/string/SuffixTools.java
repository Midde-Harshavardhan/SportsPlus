package sportspulse.string;
public class SuffixTools{
 public static int[] suffixArray(String s){
  int n=s.length(); int[] sa=new int[n], rank=new int[n], tmp=new int[n];
  for(int i=0;i<n;i++){sa[i]=i;rank[i]=s.charAt(i);} 
  for(int k=1;k<n;k*=2){sort(sa,rank,k);tmp[sa[0]]=0;for(int i=1;i<n;i++)tmp[sa[i]]=tmp[sa[i-1]]+less(sa[i-1],sa[i],rank,k);for(int i=0;i<n;i++)rank[i]=tmp[i];if(rank[sa[n-1]]==n-1)break;if(k>n/2)break;}
  return sa;
 }
 private static int less(int a,int b,int[] r,int k){int c=Integer.compare(r[a],r[b]);if(c!=0)return 1;int ra=a+k<r.length?r[a+k]:-1,rb=b+k<r.length?r[b+k]:-1;return ra==rb?0:1;}
 private static void sort(int[] sa,int[] r,int k){int[] tmp=new int[sa.length];mergeSort(sa,tmp,0,sa.length-1,r,k);}
 private static void mergeSort(int[] a,int[] tmp,int l,int h,int[] r,int k){if(l>=h)return;int m=(l+h)/2;mergeSort(a,tmp,l,m,r,k);mergeSort(a,tmp,m+1,h,r,k);int i=l,j=m+1,p=l;while(i<=m&&j<=h){if(cmp(a[i],a[j],r,k)<=0)tmp[p++]=a[i++];else tmp[p++]=a[j++];}while(i<=m)tmp[p++]=a[i++];while(j<=h)tmp[p++]=a[j++];for(i=l;i<=h;i++)a[i]=tmp[i];}
 private static int cmp(int a,int b,int[] r,int k){int c=Integer.compare(r[a],r[b]);if(c!=0)return c;int ra=a+k<r.length?r[a+k]:-1,rb=b+k<r.length?r[b+k]:-1;return Integer.compare(ra,rb);}
 public static int[] kasai(String s,int[] sa){int n=s.length();int[] rank=new int[n],lcp=new int[n];for(int i=0;i<n;i++)rank[sa[i]]=i;for(int i=0,k=0;i<n;i++){int r=rank[i];if(r==n-1){k=0;continue;}int j=sa[r+1];while(i+k<n&&j+k<n&&s.charAt(i+k)==s.charAt(j+k))k++;lcp[r]=k;if(k>0)k--;}return lcp;}
 public static int longestCommonPrefix(String a,String b){int n=Math.min(a.length(),b.length()),i=0;while(i<n&&a.charAt(i)==b.charAt(i))i++;return i;}
}
